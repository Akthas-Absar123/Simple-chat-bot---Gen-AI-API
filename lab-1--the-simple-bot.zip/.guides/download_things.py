import nltk

nltk.download('stopwords')
nltk.download('punkt')
nltk.download('webtext')
nltk.download('popular', quiet=True)